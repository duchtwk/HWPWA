# WorkAdventure Map Starter Kit - Src Folder

In this directory you can put your scripts and other source code files.

#                       Größte Lüge, funktioniert nicht, script.ts im hauptordner nutzen
